#!/bin/bash

# Build directory of llvm and clang
export BD=/home/nazim/Desktop/llvm-forked/build/bin

# Directory address of plugin's library
export PL=/home/nazim/Desktop/llvm-forked/build/lib

$BD/clang++ -std=c++0x -w -fsyntax-only '-D__sync()=' '-D__lwsync()=' '-D__isync()='  -Xclang -load -Xclang $PL/OMRChecker.so -Xclang -add-plugin -Xclang omr-checker ../../compiler/x/amd64/codegen/OMRCodeGenerator.cpp
